package apps.aw.photoviewer.java.executor;

import apps.aw.photoviewer.java.interactors.Interactor;

public interface Executor {


    void run(final Interactor interactor);
}
