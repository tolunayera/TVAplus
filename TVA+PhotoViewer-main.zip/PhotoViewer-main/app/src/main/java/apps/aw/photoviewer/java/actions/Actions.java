package apps.aw.photoviewer.java.actions;

public class Actions {
    public static int OPEN_SYSTEM_FILE_PICKER = 1;
}
