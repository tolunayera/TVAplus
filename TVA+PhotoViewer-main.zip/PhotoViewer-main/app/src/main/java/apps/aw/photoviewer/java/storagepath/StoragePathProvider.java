package apps.aw.photoviewer.java.storagepath;

import java.util.List;

public interface StoragePathProvider {

    List<StoragePath> getPaths();
}
