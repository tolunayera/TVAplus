package apps.aw.photoviewer.java;

public class Action extends ColumnViewData {

    final public int action;
    public Action(int action) {
        this.action = action;
    }
}
