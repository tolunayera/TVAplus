package apps.aw.photoviewer.java.interactors.shared;

public class NavigationOperationFocus extends NavigationOperation {
    public int index;

    public NavigationOperationFocus(int index) {
        this.index = index;
    }
}
