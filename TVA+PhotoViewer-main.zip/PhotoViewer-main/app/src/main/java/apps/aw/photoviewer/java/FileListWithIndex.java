package apps.aw.photoviewer.java;

import java.util.ArrayList;

public class FileListWithIndex {
    public ArrayList<String> list;
    public int index;

    public FileListWithIndex(ArrayList<String> list, int index) {
        this.list = list;
        this.index = index;
    }
}
