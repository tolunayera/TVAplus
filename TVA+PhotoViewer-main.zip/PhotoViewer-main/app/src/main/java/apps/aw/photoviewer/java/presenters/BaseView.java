package apps.aw.photoviewer.java.presenters;

public interface BaseView<T> {

}
