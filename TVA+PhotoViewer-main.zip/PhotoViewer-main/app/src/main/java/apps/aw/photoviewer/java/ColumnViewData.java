package apps.aw.photoviewer.java;

/**
 * This class represents either a directory, an image preview, an action or possibly something else.
 */
public abstract class ColumnViewData {
}

