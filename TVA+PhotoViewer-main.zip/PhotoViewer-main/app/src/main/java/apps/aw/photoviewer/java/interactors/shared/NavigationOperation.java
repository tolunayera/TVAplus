package apps.aw.photoviewer.java.interactors.shared;

public class NavigationOperation {
    // contains nothing
}
