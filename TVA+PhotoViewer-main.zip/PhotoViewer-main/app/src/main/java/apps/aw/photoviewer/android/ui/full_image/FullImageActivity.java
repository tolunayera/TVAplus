package apps.aw.photoviewer.android.ui.full_image;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import apps.aw.photoviewer.R;
import apps.aw.photoviewer.android.executor.MainThread;
import apps.aw.photoviewer.android.executor.ExecutingThread;
import apps.aw.photoviewer.java.interactors.linear.LinearNavigationInteractor;
import apps.aw.photoviewer.java.interactors.shared.Navigation;
import apps.aw.photoviewer.java.linearnavigator.LinearNavigatorImpl;

public class FullImageActivity
        extends AppCompatActivity
        implements FullImageFragment.OnFragmentInteractionListener {

    private static final String TAG = "FullImageActivity";

    LinearNavigationInteractor linearNavigationInteractor;

    Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_image);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        ArrayList<String> list = intent.getStringArrayListExtra("stringArrayList");
        int currentIndex = intent.getIntExtra("current", 0);

        linearNavigationInteractor = new LinearNavigationInteractor(
                new LinearNavigatorImpl(list, currentIndex),
                new ExecutingThread(),
                new MainThread()
        );

        fragment = getSupportFragmentManager().findFragmentById(R.id.full_image_fragment);
    }

    @Override
    public Navigation getNavigation() {
        return linearNavigationInteractor;
    }
}