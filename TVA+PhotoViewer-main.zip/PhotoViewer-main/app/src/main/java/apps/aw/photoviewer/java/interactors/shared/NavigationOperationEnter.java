package apps.aw.photoviewer.java.interactors.shared;

public class NavigationOperationEnter extends NavigationOperation {

    public NavigationOperationEnter() { }

}
