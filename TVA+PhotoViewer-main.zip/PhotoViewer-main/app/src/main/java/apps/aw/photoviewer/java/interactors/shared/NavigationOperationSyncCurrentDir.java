package apps.aw.photoviewer.java.interactors.shared;

public class NavigationOperationSyncCurrentDir {
    public int index;

    public NavigationOperationSyncCurrentDir(int index) {
        this.index = index;
    }
}
